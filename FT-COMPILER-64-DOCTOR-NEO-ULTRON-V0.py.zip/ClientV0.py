import os
import sys

# Get the baserom path.
baserom_path = sys.argv[1]

# Get the region.
region = sys.argv[2]

# Check if the region is valid.
if region not in ["USA", "JP", "EU"]:
  print("Invalid region.")
  sys.exit(1)

# Get the baserom name.
baserom_name = os.path.basename(baserom_path)

# Get the ROM name.
rom_name = baserom_name + ".z64"

# Create the ROM directory.
rom_dir = os.path.dirname(rom_name)
if not os.path.exists(rom_dir):
  os.mkdir(rom_dir)

# Open the ROM file for writing.
with open(rom_name, "wb") as rom_file:

  # Write the ROM header.
  rom_file.write(b"\x80\x37\x00\x00\x00\x00\x00\x00")

  # Write the baserom data.
  with open(baserom_path, "rb") as baserom_file:
    for chunk in baserom_file:
      rom_file.write(chunk)

  # Write the region code.
  rom_file.write(region.encode("ascii"))

print("ROM generated successfully.")
## [@FlameslLC20XX]